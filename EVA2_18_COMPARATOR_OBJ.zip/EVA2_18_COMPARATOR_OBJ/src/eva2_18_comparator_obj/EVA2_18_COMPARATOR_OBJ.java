/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_18_comparator_obj;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

/**
 *
 * @author Usuario
 */
public class EVA2_18_COMPARATOR_OBJ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<Persona> llDatosPersona = new LinkedList<>();
        llDatosPersona.add(new Persona("Antonio", "Martinez", 15));
        llDatosPersona.add(new Persona("Zenobia", "Julimez", 60));
        llDatosPersona.add(new Persona("Carmelo", "Julimez", 30));
        llDatosPersona.add(new Persona("Mateo", "Bacilio", 35));
        llDatosPersona.add(new Persona("Pedro", "Paramo", 27));
        llDatosPersona.add(new Persona());
        //Imprimios
        imprimeLista(llDatosPersona);

        Comparator cmpApe = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                //Los objetos son personas
                Persona per1, per2;
                per1 = (Persona) o1;
                per2 = (Persona) o2;
                //DE cada persona recuperamos el apelldio
                String ape1, ape2;
                ape1 = per1.getsApellido();
                ape2 = per2.getsApellido();
                char c1, c2;
                c1 = ape1.charAt(0);
                c2 = ape2.charAt(0);
                /*
                o1 < o2  Un numero menor a cero (-)
                o1 == o2 cero
                o1 > o2  Un numero mauor a cero (+)
                 */
                return c1 - c2;

            }
        };
        Collections.sort(llDatosPersona, cmpApe);
        imprimeLista(llDatosPersona);

        //Comparator edad
        Comparator cmpEdad = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                //Los objetos son personas
                Persona per1, per2;
                per1 = (Persona) o1;
                per2 = (Persona) o2;
                //DE cada persona recuperamos la edad
                int edad1, edad2;
                edad1 = per1.getiEdad();
                edad2 = per2.getiEdad();

                /*
                o1 < o2  Un numero menor a cero (-)
                o1 == o2 cero
                o1 > o2  Un numero mauor a cero (+)
                 */
                return edad1 - edad2;

            }
        };
        Collections.sort(llDatosPersona, cmpEdad);
        imprimeLista(llDatosPersona);

        //Compaator Apellido-edad
        Comparator cmpApeEdad = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                //Los objetos son personas
                Persona per1, per2;
                per1 = (Persona) o1;
                per2 = (Persona) o2;
                //DE cada persona recuperamos el apelldio
                String ape1, ape2;
                ape1 = per1.getsApellido();
                ape2 = per2.getsApellido();
                char c1, c2;
                c1 = ape1.charAt(0);
                c2 = ape2.charAt(0);
                /*
                o1 < o2  Un numero menor a cero (-)
                o1 == o2 cero
                o1 > o2  Un numero mauor a cero (+)
                 */
                if (c1 - c2 == 0) {
                    int edad1, edad2;
                    edad1 = per1.getiEdad();
                    edad2 = per2.getiEdad();
                    return edad1 - edad2;
                }
                return c1 - c2;

            }
        };
        Collections.sort(llDatosPersona, cmpApeEdad);
        imprimeLista(llDatosPersona);
    }

    public static void imprimeLista(LinkedList<Persona> llLista) {
        for (Persona persona : llLista) {
            System.out.println("Nombre: " + persona.getsNombre());
            System.out.println("Apellido: " + persona.getsApellido());
            System.out.println("Edad: " + persona.getiEdad());
            System.out.println("--------------------------------");
        }
    }

}

class Persona {

    private String sNombre;
    private String sApellido;
    private int iEdad;

    public String getsNombre() {
        return sNombre;
    }

    public void setsNombre(String sNombre) {
        this.sNombre = sNombre;
    }

    public String getsApellido() {
        return sApellido;
    }

    public void setsApellido(String sApellido) {
        this.sApellido = sApellido;
    }

    public int getiEdad() {
        return iEdad;
    }

    public void setiEdad(int iEdad) {
        this.iEdad = iEdad;
    }

    public Persona(String sNombre, String sApellido, int iEdad) {
        this.sNombre = sNombre;
        this.sApellido = sApellido;
        this.iEdad = iEdad;
    }

    public Persona() {
        this.sNombre = "Daniel";
        this.sApellido = "Carrillo";
        this.iEdad = 21;
    }

}


    
