/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_5_factorial;

/**
 *
 * @author invitado
 */
public class EVA2_5_Factorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Factorial: "+calculaFactorial(5));
        System.out.println("Suma factorial: "+calculaSuma(5));
    }
    public static int calculaFactorial(int iVal){
     //una condicon para detener
        if(iVal==0)
            return 1;
        //una llamada recursiva
        else{
            return iVal * calculaFactorial(iVal-1);
        }
    }
    //calculra la sumatoria recursiva
    public static int calculaSuma(int iVal){
        if (iVal==0)
            return 0;
        else{
            return iVal + calculaSuma(iVal-1);
        }
    }
}
