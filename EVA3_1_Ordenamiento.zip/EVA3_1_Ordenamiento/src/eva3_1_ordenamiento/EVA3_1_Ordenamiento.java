/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva3_1_ordenamiento;

/**
 *
 * @author Mary
 */
public class EVA3_1_Ordenamiento {


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] aPrueba=new int[20];
        int[] aPrueba2=new int[20];
        for(int i=0;i<aPrueba.length;i++){
            aPrueba[i]=(int)(Math.random()*100);
            aPrueba2[i]=aPrueba[i];
        }
        System.out.println("Datos de origen: ");
        
        impArray(aPrueba);
        /*long ini= System.nanoTime();
        selectionSort(aPrueba);
        long fin= System.nanoTime();
        impArray(aPrueba); 
        long ini2= System.nanoTime();
        insertionSort(aPrueba2);
        long fin2= System.nanoTime();
        impArray(aPrueba2);
        System.out.println("prueba 1: "+(fin-ini));
        System.out.println("prueba 2: "+(fin2-ini2));
        */
        bubbleSort(aPrueba);
        //insertionSort(aPrueba);
        impArray(aPrueba);
    }
    
    public static void impArray(int[] aDatos){
        for(int i=0;i<aDatos.length;i++){
            System.out.print("["+aDatos[i]+"]");
        }
        System.out.println("\n----------------------------------------------------------------------------------");
    }
    
    public static void selectionSort(int[] aDatos){//LISTA EN DESORDEN
        for(int i=0;i<aDatos.length;i++){
            int min=i;
            //MARCAR LA POSICIÓN DEL MÁS PEQUEÑO
            for(int j=i+1;j<aDatos.length;j++){
                if(aDatos[j]<aDatos[min]){
                    min=j;
                }
            }
            //INTERCAMBIAR CON LA PRIMER POSICIÓN DE LA LISTA EN DESORDEN
            int temp=aDatos[min];
            aDatos[min]=aDatos[i];
            aDatos[i]=temp;
        }
    }
    public static void insertionSort(int[] aDatos){
        for(int i=1;i<aDatos.length;i++){
            int men=i;
            //MARCAR LA POSICIÓN DONDE VA A IR EL MÁS PEQUEÑO
            for(int j=i-1;j>=0;j--){
                if(aDatos[i]<aDatos[j]){
                    men=j;
                }
            }
            //RECORRER LOS VALORES A LA POSICION CORRESPONDIENTE
            int temp=aDatos[i];
            for(int k=i;k>men;k--){
                aDatos[k]=aDatos[k-1];
            }
            aDatos[men]=temp;
        }
    }
    
    public static void bubbleSort(int[] aDatos){
        for(int i=0;i<aDatos.length;i++){
            for(int j=i+1;j<aDatos.length;j++){
                if(aDatos[j-1]>aDatos[j]){
                    int temp=aDatos[j-1];
                    aDatos[j-1]=aDatos[j];
                    aDatos[j]=temp;
                }
            }
        }
    }
    
    
}


