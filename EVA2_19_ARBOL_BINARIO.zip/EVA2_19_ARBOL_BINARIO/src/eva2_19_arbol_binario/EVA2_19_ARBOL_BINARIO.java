/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_19_arbol_binario;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class EVA2_19_ARBOL_BINARIO {
 private Nodo nRoot;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArbolBinario abMiArbol=new ArbolBinario();
     try{
         abMiArbol.agregarNodo(new Nodo(15));
         abMiArbol.agregarNodo(new Nodo(20));
         abMiArbol.agregarNodo(new Nodo(33));
         abMiArbol.agregarNodo(new Nodo(24));
         abMiArbol.agregarNodo(new Nodo(35));
     }catch(Exception ex){
      Logger.getLogger(EVA2_19_ARBOL_BINARIO.class.getName()).log(level.SEVERE,null,ex);
 //Logger.getLogger(NewClass.class.getName())
//.getLogger(NewClass.class.getName()).log(level.SEVERE,null,ex);
     }abMiArbol.imprimirPreorden();    
    }

    public EVA2_19_ARBOL_BINARIO(){
    nRoot = null;
    }
    
    public EVA2_19_ARBOL_BINARIO(Nodo nNuevo) {
        this.nRoot = nNuevo;
    }
    
    public void agregarNodo(Nodo nNuevo ) throws Exception{
         if(nRoot == null){
             nRoot = nNuevo;
         }else{
             agregarNodoRecur(nRoot, nNuevo);
         }
    }
    private void agregarNodoRecur(Nodo nNuevo, Nodo nActual) throws Exception{
        if(nNuevo.getiDato() > nActual.getiDato()){//ES MAYOR VA A LA DERECHA
            if(nActual.getnSig() == null){//VERIFICAMOS SI EL LADO DERECHO ESTA VACIO (null)
                nActual.setnSig(nNuevo);
            }else{//No esta vacia
                agregarNodoRecur(nNuevo, nActual.getnSig());
            }
        }else if(nNuevo.getiDato() < nActual.getiDato()){//ES MENOS VA A LA IZQUIERDA
            if(nActual.getnPrev()== null){//VERIFICAMOS SI EL LADO IZQUIERDO ESTA VACIO (null)
                nActual.setnPrev(nNuevo);
            }else{//No esta vacia
                agregarNodoRecur(nNuevo, nActual.getnPrev());
            }
        }else{
            throw new Exception("No se valen metodos iguales");
        }
            
    }
private void agregarNodoRecurs(Nodo nNuevo, Nodo nActual) throws Exception{
        if(nActual!=null){//ES MAYOR VA A LA DERECHA
            System.out.println(nActual.getiDato()+" ");
            preOrden(nActual.getnPrev());
            preOrden(nActual.getnSig());
            }

}

    private void preOrden(Nodo nPrev) {
       
    }

    private static class ArbolBinario {

        public ArbolBinario() {
        }

        private void agregarNodo(Nodo nodo) {
           
        }

        private void imprimirPreorden() {
           
        }
    }

    private static class level {

        private static Level SEVERE;

        public level() {
        }
    }
    }
    

