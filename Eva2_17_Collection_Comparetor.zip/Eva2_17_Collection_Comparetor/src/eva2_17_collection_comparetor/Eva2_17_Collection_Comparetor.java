/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package eva2_17_collection_comparetor;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

/**
 *
 * @author invitado
 */
public class Eva2_17_Collection_Comparetor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //comparator recibe dos objetos de 01 y 02//postivo=mayor 02>01//negativo=menor01>02//cero=iguales
    LinkedList<String>IsMiListaOrdInv= new LinkedList<>();
    IsMiListaOrdInv.add("Juan");
    IsMiListaOrdInv.add("Alonso");
    IsMiListaOrdInv.add("Chavira");
    IsMiListaOrdInv.add("Zaire");
    IsMiListaOrdInv.add("Barrientos");
        System.out.println(IsMiListaOrdInv);
        Collections.sort(IsMiListaOrdInv);
        System.out.println(IsMiListaOrdInv);
        //ordenar de la z a a
        Comparator xmOrdenaZ_A=new Comparator() {

        @Override
        public int compare(Object o1, Object o2) {
      String cade1,cade2;
      cade1=(String)o1;
      cade2=(String)o2;
      int iResu=0;
      char c1,c2;
      cade1.length();
      
      c1=cade1.charAt(0);
      c2=cade2.charAt(0);
      iResu=c2-c1;//a -z
      //iResu=c1-c2;// a-z=9
      return iResu;
    }//comparator es una interface//la interfaz
    
    };
        Collections.sort(IsMiListaOrdInv,xmOrdenaZ_A );
        System.out.println(IsMiListaOrdInv);
    
}

}//tambien hay que modificar para que tome todo el orden
//modificar esta practica

