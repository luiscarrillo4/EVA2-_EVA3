/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_11_collections_arraylist;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Mary
 */
public class EVA2_11_COLLECTIONS_ARRAYLIST {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Integer> aIsMiArreglo= new ArrayList();
        // los colection usan tipode datos genericos
        aIsMiArreglo.add(10);
        aIsMiArreglo.add(20);
        aIsMiArreglo.add(30);
        aIsMiArreglo.add(40);
        // se pueden recorrer con un for
        for (int i = 0; i <  aIsMiArreglo.size(); i++) {
            System.out.println( aIsMiArreglo.get(i)+" - ");
        }
        System.out.println("");
        /*for (Integer integer : aIsMiArreglo) {
            System.out.println(integer+" - ");
        }/*
        //o usando iteradores
        */
        /*for (Iterator<Integer> iterator= aIsMiArreglo.iterator();iterator.hasNext();) {
            Integer next=iterator.next();
            System.out.println(next+" - ");
        }*/
         aIsMiArreglo.remove((Object)30);
         for (Integer integer : aIsMiArreglo) {
             System.out.println(integer+" - ");
        }
         System.out.println("");
          aIsMiArreglo.remove(0);
          for (Integer integer : aIsMiArreglo) {
              System.out.println(integer+" - ");
        }
           aIsMiArreglo.clear();
           System.out.println("Lista despues de borrar");
           for (Integer integer : aIsMiArreglo) {
               System.out.println(integer+ " - ");
        }
    }
    
}
