/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_9_queue;

/**
 *
 * @author Mary
 */
public class MyQueue {
    private Nodo nIni;
    private Nodo nFin;
    private int contador;

    public MyQueue() {
        this.nIni = null;
        this.nFin = null;
       contador = 0;
    }

    public MyQueue(Nodo nIni) {
        this.nIni = nIni;
        this.nFin=nIni;
        contador=1;
    }
    public void add(Nodo nNodo){
        if (nIni==null) {// la lista esta vacia
            nIni=nNodo;
            nFin=nNodo;
            
        }else{// si ka lista tiene elementos
            //hay que moverlos al final de la lista
            Nodo nTemp=nIni;
            while(nTemp.getnSig()!=null){
                nTemp=nTemp.getnSig();
            }
            //conectar el nevo nodo al final de la lista
            nTemp.setnSig(nNodo);
            nNodo.setPrev(nTemp);
            nFin.setnSig(nNodo);
            nFin=nNodo;
        }
    }
    public int pop() throws Exception{// lee el nodo y lo elimina(el primer nodo
        if (nIni==null) {
            throw new Exception("No hay elementos en la lista");
        }if (nIni.getnSig()==null) {
            Nodo nTemp=nIni;
            nIni=null;
            nFin=null;
            return nTemp.getiDato();
        }else{
            Nodo nTemp=nIni;
            nIni.getnSig().setPrev(null);
            nIni=nIni.getnSig();
            return nTemp.getiDato();
        }
        //es una lista doble se debe de conectar en ambos
        //verificar los casos:no hay nodods,un nodo o n nodos
        //que pasa con nIni nFin
    }
    
    
    
}
