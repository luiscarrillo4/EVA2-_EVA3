/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_9_queue;

/**
 *
 * @author Mary
 */
public class Nodo {
     //Atributos: 1. dato a almacenar 2. Enlace al siguiente o anterior nodo
    private int iDato;
    private Nodo nSig;
    private Nodo prev;

    public Nodo() {
        this.nSig = null;
        this.prev=null;
    }
    public Nodo(Nodo prev){
        this.prev=prev;
    }

    public Nodo(int iDato) {
        this.iDato = iDato;
        this.nSig = null;
        this.prev=null;
    }

    public Nodo(int iDato, Nodo nSig,Nodo prev) {
        this.iDato = iDato;
        this.nSig = nSig;
        this.prev=null;
    }

    public void setnSig(Nodo nSig) {
        this.nSig = nSig;
    }

    public Nodo getnSig() {
        return nSig;
    }

    public int getiDato() {
        return iDato;
    }
    public Nodo getPrev(){
        return prev;
    }
    public void setPrev(Nodo prev){
        this.prev=prev;
    }

    public void setiDato(int iDato) {
        this.iDato = iDato;
    }
}
