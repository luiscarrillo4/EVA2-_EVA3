/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Usuario
 */
public class eva2_7_listas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         ListaSimple lsMiLista = new ListaSimple();
        //lsMiLista.printList();
        //lsMiLista.add(new Nodo (10));
        //lsMiLista.add(new Nodo (20));
        //lsMiLista.add(new Nodo (30));
        //lsMiLista.add(new Nodo (40));
        //lsMiLista.add(new Nodo (50));
       for (int i = 0; i < 10; i++) {
           lsMiLista.add(new Nodo(30));
          // System.out.println("hay" + lsMiLista.count() + "nodos");
        } 
       lsMiLista.printList();
       try{
           lsMiLista.insertAt(new Nodo(99999), 8);
       }catch(Exception e){
           e.printStackTrace();
       }
        System.out.println("");
        lsMiLista.printList();
        System.out.println("");
        System.out.println("Buscamos 99999 y esta en la posiciion:"+lsMiLista.find(99999));
        System.out.println("Buscamos el 30 y esta en la poscicion:"+lsMiLista.find(30));
        lsMiLista.add(new Nodo(111111));
         System.out.println("");
        lsMiLista.printList();
        //borrrar
        try{
          lsMiLista.removeAt(11);  
        }catch(Exception e){
           e.printStackTrace();
        }
       
        try{
           System.out.println("el valor de la posicion 2= "+lsMiLista.getValueAt(2)); 
        }catch(Exception e){
           e.printStackTrace();
       }
        
       /*lsMiLista.clear();
       if (lsMiLista.isEmpty())
            System.out.println("listra vacia");
       else
            System.out.println("hay elementos en la lista");
       lsMiLista.printList();*/
       // try {//try  
         //   lsMiLista.insertAt(new Nodo(5),8);
            
           
             
             //int iVal[]=new int [1000000];
             //for (int i = 0; i < 1000000; i++) {
               //}
             //}
       /*} catch (Exception ex) {
            Logger.getLogger(EVA2_7_LISTAS.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    }
    }
    
