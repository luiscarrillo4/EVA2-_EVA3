/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Nodo {
     //Atributos: 1. dato a almacenar 2. Enlace al siguiente o anterior nodo
    private int iDato;
    private Nodo nSig;

    public Nodo() {
        this.nSig = null;
    }

    public Nodo(int iDato) {
        this.iDato = iDato;
        this.nSig = null;
    }

    public Nodo(int iDato, Nodo nSig) {
        this.iDato = iDato;
        this.nSig = nSig;
    }

    public void setnSig(Nodo nSig) {
        this.nSig = nSig;
    }

    public Nodo getnSig() {
        return nSig;
    }

    public int getiDato() {
        return iDato;
    }

    public void setiDato(int iDato) {
        this.iDato = iDato;
    }
}
