
import java.util.Collections;
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<String> IsMiLista=new LinkedList();
        IsMiLista.add("hola");
         IsMiLista.add(" ");
          IsMiLista.add("mundo");
           IsMiLista.add("cruel");
            IsMiLista.add("!!");
        System.out.println( IsMiLista);
        Collections.sort(IsMiLista);//lo ordena queda igual
        System.out.println( IsMiLista);// sort-->ordenamiento natural
        for (String string : IsMiLista) {
            System.out.print(string);
        }
        //lista de numeros
        System.out.println("\n -----");
        LinkedList<Integer> IsMiListaEnt =new LinkedList<>();
        IsMiListaEnt.add(10);
         IsMiListaEnt.add(50);
          IsMiListaEnt.add(80);
           IsMiListaEnt.add(3);
            IsMiListaEnt.add(15);
        System.out.println( IsMiLista);
        Collections.sort(IsMiLista);
        System.out.println(IsMiLista);
    }
    
}
