
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> ListaEnteros= new ArrayList();
        ListaEnteros.add("Hola");
        
        GuardaeAlgo<Integer> objGuardar = new GuardaeAlgo();
        objGuardar.setCade(100);
        System.out.println("el valor es "+objGuardar.getCade());
    }
}
    class GuardaeAlgo<T>{
        private T cade;
        public T getCade(){
            return cade;
        }
        public GuardaeAlgo(){
            
        }
        public void setCade(T cade){
            this.cade=cade;
        }
        public GuardaeAlgo(T cade){
            this.cade=cade;
        }
}