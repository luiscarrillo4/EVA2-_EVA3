/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_13_collections_double_list;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Mary
 */
public class EVA2_13_COLLECTIONS_DOUBLE_LIST {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Queue<Integer> queCola= new LinkedList();    
        queCola.add(10);
        queCola.add(20);
        queCola.add(30);
        queCola.add(40);
        queCola.add(50);
        
        
        System.out.println("El primer elemento es:"+queCola.element());
        System.out.println("El primer elemento es:  (peek)"+queCola.peek());
        System.out.println("El primer elemento es:  (poll)"+queCola.poll());
        System.out.println("El primer elemento es:  (peek)"+queCola.peek());
    }
    
}
