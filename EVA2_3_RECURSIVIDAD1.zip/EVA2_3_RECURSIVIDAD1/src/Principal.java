/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       meLlamoamimismo();//llamada a funcion
    }
    public static void meLlamoamimismo(){
        System.out.println("Hola mundo");
        meLlamoamimismo();
    }
}
//el metodo debe llamarsea si mismo
//2 debe haber algo que cierre la recursividad