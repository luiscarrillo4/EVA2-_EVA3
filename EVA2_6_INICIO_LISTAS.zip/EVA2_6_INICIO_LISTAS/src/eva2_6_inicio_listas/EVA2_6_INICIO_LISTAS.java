/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_6_inicio_listas;

/**
 *
 * @author Home
 */
public class EVA2_6_INICIO_LISTAS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Nodo nNod1=new Nodo();
        nNod1.iDato = 10;
        nNod1.nSig=null;
        Nodo nNod2=new Nodo();
        nNod2.iDato = 20;
        nNod1.nSig=null;
        Nodo nNod3=new Nodo();
        nNod3.iDato = 30;
        nNod1.nSig=null;
        //Hasta aqui, cada nodo es independiente, hay que enlazarlos.
        //nodo1 --> nodo2 --> nodo3 --> null
        nNod1.nSig = nNod2;
        nNod2.nSig = nNod3;
        //probar la cadena de nodos
        System.out.println("Nodo 1 =" + nNod1.iDato);
        System.out.println("Nodo 2 =" + nNod2.iDato);
        System.out.println("Nodo 2 (cadena) =" + nNod1.nSig.iDato);
        System.out.println("Nodo 3 =" + nNod3.iDato);
        System.out.println("Nodo 3 (cadena) =" + nNod1.nSig.nSig.iDato);
        //Recorrer una lista
        Nodo nTemp = nNod1;
        while(nTemp != null){
            System.out.println("Nodo = " + nTemp.iDato );
            nTemp= nTemp.nSig;
        }
    }
    
}

class Nodo{
    public int iDato;//Esto es lo que guardamos (datos)
    public Nodo nSig;//Enlace para crear la lista (cadena de nodos)
}
