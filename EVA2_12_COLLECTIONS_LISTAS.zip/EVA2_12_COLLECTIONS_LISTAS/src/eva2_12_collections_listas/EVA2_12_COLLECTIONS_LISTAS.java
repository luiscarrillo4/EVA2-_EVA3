/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_12_collections_listas;

import java.util.LinkedList;

/**
 *
 * @author Mary
 */
public class EVA2_12_COLLECTIONS_LISTAS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //existen ods tipos de listas la simple y la doble
        LinkedList <String> ListPalabras= new LinkedList();
        //= new LinkedList<String>();   
        ListPalabras.add("Hola");
        ListPalabras.add(" ");
        ListPalabras.add("Mundo");
        ListPalabras.add(" ");
        ListPalabras.add("Cruel");
        System.out.println(ListPalabras);
        for (String palabra : ListPalabras) {
            System.out.print(palabra);
        }
        ListPalabras.removeLast();
        System.out.println("");
        for (String Palabra : ListPalabras) {
            System.out.print(Palabra);
        }
        }
    
}
