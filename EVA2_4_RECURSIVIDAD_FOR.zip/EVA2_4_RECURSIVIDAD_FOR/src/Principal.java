/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     forRecursivoDes(5);
     forRecursivoalr(5);
    }
    public static void forRecursivoDes(int iVal){
        System.out.println(iVal+ " - ");// lo imprimo
        if(iVal>1)
        forRecursivoDes(iVal-1);//le resto uno y lo mando de nuevo
        System.out.println("Terminado!!");
    }
    public static void forRecursivoalr(int iVal){
     System.out.println((iVal-4) + " + ");// imprime el valor 1
     if(iVal<9)//se comprar se es menor a 9
     forRecursivoalr(iVal+1);//se le suma uno
     System.out.println("Listo");   
    
        
    }
}
