/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_8_listas_dobles;

/**
 *
 * @author Mary
 */
public class ListaDoble {
    private Nodo nIni;//El nodo que marca el inicio de la lista
    private Nodo nFin;
    private int iCount;
    
    public ListaDoble(){
        nIni = null;
        nFin=null;
        iCount=0;
    }

    public ListaDoble(Nodo nNodo) {
        this.nIni =nIni;
        this.nFin= nIni;//checar
        iCount=1;
    }
    
    //agergar al final de la lista
    public int add(Nodo nNodo){
        //la lisat esta vacia
        if(nIni== null){
         nIni=nNodo;
         nFin=nNodo; //checar
        } else {// la  lista tiene elementos
            //hay que movernos al final de lista
            Nodo nTemp = nIni;
            while(nTemp.getnSig()!=null){// condicion  checar
             nTemp=nTemp.getnSig();// para avabnzar   
            }
            //conectar el nuevo bnodo al final de la lista 
            nTemp.setnSig(nNodo);//agregar
            nNodo.setPrev(nTemp);
            nFin.setnSig(nNodo);//se le asigna al nuevo nodo
            nFin=nNodo;
            
        }
        iCount++;//cada vez que agregamos un nodo incrementamos
        return iCount;
    }
    //imprimir datos de la lista
    public void printList(){
        Nodo nTemp= nIni;
        System.out.println("");
        System.out.println("Orden Normal:");
        while(nTemp !=null){
                System.out.print(nTemp.getiDato()+" - ");
            nTemp=nTemp.getnSig();
        }
        System.out.println("");
        System.out.println("Orden hacia atras: ");
        nTemp=nFin;
        while(nTemp!=null){
            System.out.print(nTemp.getiDato()+" - ");
            nTemp=nTemp.getPrev();
        }
    }
    //eliminar todos los elemntos de la lista
    public void clear(){
    nIni=null;
    nFin=null;
}
    //devuelve true si la lista esta vacia, false si tiene elementos
    public boolean isEmpty(){
        if (nIni !=null) 
            return false;//si hay nodo en la lista
            else
            return true;
        
    }
    public int count(){
       //FUERZA BRUTA
        /*int iCont=0;
        Nodo nTemp= nIni;
        while(nTemp !=null){
        iCont++;
         nTemp=nTemp.getnSig(); 
    }
        return iCont; */
        return iCount;
    }
    //insertar en una `posicion de la lista
    public void insertAt(Nodo nNodo, int iPos) throws Exception{
    //analicen los diferentes casos
        if(iPos<0){// la primer posicion es cero
            throw new Exception("no se puede agregar en un numero negativo");// la primera
            // que es una excepcion; son generados por el programa, aveces mata su programa
            //error: mata el programa son fallas del entorno de su programa
            //trycath: atrapar la excepcion
        }else  if (iPos>count()){// si queeremos insertar en una poscion mas aya de la lista
             throw new Exception("la ppsicion de insercion es mayor al tamano de la lista");
        }else if(iPos==0){//insertar al incio de la lista 0
            nNodo.setnSig(nIni);//nuevo.sgguiente =nIni
           nIni.setPrev(nNodo);
            nIni=nNodo;//cambia direcciones
            
        } else { //si se inserta en medio  
          //se sabe que tantas veces se debe de mover
            Nodo nTemp=nIni;
            for (int i = 0; i < (iPos-1); i++) {// da el nodo previo
               nTemp= nTemp.getnSig();
            }
            nNodo.setnSig(nTemp.getnSig());
            nNodo.setPrev(nTemp);
            Nodo nTemp2=nTemp.getnSig();
            nTemp2.setPrev(nNodo);
            nTemp.setnSig(nNodo);
            
        
     
}
    iCount++;
}
    //leer un valor en una posicion
    public int getValueAt(int iPos) throws Exception{
            if(iPos<0){// la primer posicion es cero
            throw new Exception("no se puede agregar en un numero negativo");
        }else  if (iPos>=count()){// si queeremos insertar en una poscion mas aya de la lista
             throw new Exception("la ppsicion de insercion es mayor al tamano de la lista");
        }else{
     Nodo nTemp=nIni;
     for (int i = 0; i < iPos; i++) {// da el nodo previo
     nTemp= nTemp.getnSig();
            }
     return nTemp.getiDato();
    }
}
    // enxcontrar un elemento en una lista
    //se recorrera el primer valor
    public int find(int iValor){
        int iResu=-1;
        //buscar el elemento
        
        int iPos=0;// es el contador para la posicion
         Nodo nTemp= nIni;
        while(nTemp !=null){
            if(nTemp.getiDato()==iValor){
                iResu=iPos;
              break;
            }
            nTemp=nTemp.getnSig();
            iPos++;
        }
        return iResu;
                
    }
    //eliminar una posciion de un arreglo
    public void removeAt(int iPos) throws Exception{
        if(iPos<0){// la primer posicion es cero
            throw new Exception("no se puede borrar un nodo");
        }else  if (iPos>=count()){// si queeremos insertar en una poscion mas aya de la lista
             throw new Exception("la posicion de borrrado es mayor que el tamano de la lista");
        }else{//aqui si se puede borrar
           // sie le nodo es el cero y solo hay un nodo en la lista
            if ((iPos==0)&&(count()==1)) {
                nIni=null;
                nFin=null;
            }
       Nodo nTemp=nIni;
       for (int i = 0; i < (iPos-1); i++) {// da el nodo previo
       nTemp= nTemp.getnSig();
            }
       Nodo nTemp2=nTemp.getnSig().getnSig();
            if (nTemp2==null) {
                nFin=nTemp.getnSig();
            }else{
                nTemp2.setPrev(nTemp);
            }
       
       nTemp.setnSig(nTemp.getnSig().getnSig());//para saltear 
                if (nTemp.getnSig()==null) {//borramos el ulrtimo nodo de la lista
                    nFin=nTemp;
                }
                iCount--;//s i borramos un nodo dcrementoamos el conteo
    
        
    }
    
} 
}
